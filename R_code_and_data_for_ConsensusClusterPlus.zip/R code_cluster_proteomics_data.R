if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("ConsensusClusterPlus")


library(ConsensusClusterPlus)

tempdir<-setwd("D:\\FROM Q\\FROM Q\\Creighton\\ConsensusClusterPlus 071472021")
all_data1<-read.table("data.txt",h=T) 
head(all_data1)
dim(all_data1)
#[1] 2000 2003
class(all_data1)
#a<-complete.cases(all_data1)
#summary(a)
#all_data<-data.matrix(all_data1[,2:33], rownames.force = NA)
# Apply na.omit function

all_data<-data.matrix(all_data1[,2:length(all_data1)])
all_data[is.na(all_data)]<-0


class(all_data)
dim(all_data)
#[1] 2000 2002
#head(all_data)

#We selected 80% item resampling (pItem), 80% gene resampling
#(pFeature), a maximum evalulated k of 20 are
#evaluated (maxK), 1000 resamplings (reps), agglomerative hierarchical clustering
#algorithm (clusterAlg) upon 1- Pearson correlation distances (distance), gave
#our output a title (title).
#We also used a specific random seed so that this example is repeatable
#(seed).

results = ConsensusClusterPlus(all_data,maxK=20,reps=1000,pItem=0.8,pFeature=1,
                               clusterAlg="hc",distance="pearson",
                               innerLinkage="ward.D2", finalLinkage="ward.D2",
                               seed=1262118388.71279,plot="pdf",writeTable=T)
icl = calcICL(results)
#results[2]

setwd("D:\\FROM Q\\FROM Q\\Creighton\\ConsensusClusterPlus 071472021\\untitled_consensus_cluster")
getwd()
filedir<-"D:\\FROM Q\\FROM Q\\Creighton\\ConsensusClusterPlus 071472021\\untitled_consensus_cluster"

File <- list.files(path = filedir, pattern = paste("consensusClass","*\\.csv$"))

File
dt1<-read.csv(file=File[1],h=F)


dt<-matrix(NA,nrow=dim(dt1)[1],ncol=length(File))

dt[,1]<-dt1[,2]
head(dt[,1])
for (i in 2:length(File))
{temp<-read.csv(file=File[i],h=F)
cluster<-temp[,2]
dt[,i]<-cluster
}
dim(dt)


write.table(dt, file = "cluster_all_data.xls", sep="\t")
write.table(File, file = "filename.xls", sep="\t")


